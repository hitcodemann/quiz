class Questions {
  String? questionText;
  bool? questionAnswer;

  Questions(this.questionText, this.questionAnswer) {}
}
