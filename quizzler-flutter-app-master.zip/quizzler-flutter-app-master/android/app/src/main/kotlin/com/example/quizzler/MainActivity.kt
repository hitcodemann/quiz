package com.example.quizzler

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
